"""LogsView() custom component"""
from __future__ import annotations

import os
import io
import logging
import queue
import subprocess
import time
import traceback
from contextlib import contextmanager, redirect_stderr, redirect_stdout
from dataclasses import dataclass
from datetime import datetime
from functools import wraps
from logging.handlers import QueueHandler
from multiprocessing import Process
from multiprocessing import Queue as mpQueue
from typing import Any, Callable, Generator, List, Literal, NoReturn

from gradio.components.base import Component
from gradio.events import Events

LOGGING_LEVEL_T = Literal["INFO", "DEBUG", "WARNING", "ERROR", "CRITICAL"]


@dataclass
class Log:
    level: LOGGING_LEVEL_T
    message: str
    timestamp: str


class LogsViewRunner:
    """
    Runner to execute a command or a function and capture logs in real-time.

    Parameters:
        date_format: Date format to use for logs timestamps. Default is "%Y-%m-%d %H:%M:%S".

    Attributes:
        date_format: Date format to use for logs timestamps.
        logs: List of `Log` logs.
        exit_code: Exit code of the process or function. None if not run yet.
        process: Process or subprocess.Popen object. None if not run yet.

    Usage:
    ```python
    runner = LogsViewRunner()
    for logs in runner.run_command(["echo", "Hello World"]):
        for log in logs:
            print(log.timestamp, log.level, log.message)
    """

    def __init__(self, date_format: str = "%Y-%m-%d %H:%M:%S"):
        self.date_format = date_format
        self.logs: List[Log] = []

        # Runner state
        self.exit_code: int | None = None
        self.process: Process | subprocess.Popen | None = None

    def log(
        self,
        message: str,
        level: LOGGING_LEVEL_T = "INFO",
        timestamp: datetime | float | int | str | None = None,
    ) -> List[Log]:
        if timestamp is None:
            timestamp = time.time()
        if isinstance(timestamp, (float, int)):
            timestamp = datetime.fromtimestamp(timestamp)
        if isinstance(timestamp, datetime):
            timestamp = timestamp.strftime(self.date_format)
        self.logs.append(Log(level=level, message=message, timestamp=timestamp))
        return self.logs

    def log_from_record(self, record: logging.LogRecord) -> List[Log]:
        return self.log(
            message=record.getMessage(),
            level=record.levelname,
            timestamp=record.created,
        )

    def _log_from_queue(self, mp_queue: mpQueue) -> Generator[List[Log], None, None]:
        while True:
            try:
                line = mp_queue.get_nowait()
                if isinstance(line, logging.LogRecord):
                    yield self.log_from_record(line)
                else:
                    yield self.log(line)
            except queue.Empty:
                break

    def run_command(
        self, command: List[str], cwd: str, **kwargs
    ) -> Generator[List[Log], None, None]:
        """Run a command in a subprocess and yield logs in real-time."""
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        env["PYTHONUNBUFFERED"] = "1"
        if cwd is None:
            cwd = os.path.dirname(os.path.abspath(__file__))

        self.process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            shell=True,
            env=env,
            bufsize=0,
            cwd=cwd,
#            universal_newlines=True,
#            text=True,
            **kwargs,
        )
        if self.process.stdout is None:
            raise ValueError("stdout is None")

        yield self.log(f"Running {' '.join(command)}")
        for line in self.process.stdout:
            yield self.log(line.decode('utf-8', errors='replace').strip())
            #yield self.log(line.strip())

        self.process.stdout.close()
        self.exit_code = self.process.wait()
        if self.exit_code:
            yield self.log(f"Command exited with code {self.exit_code}", level="ERROR")
        else:
            yield self.log("Command exited successfully", level="INFO")

    def run_python(
        self,
        fn: Callable,
        log_level: int = logging.INFO,
        logger_name: str | None = None,
        **kwargs,
    ) -> Generator[List[Log], None, None]:
        """Run Python code in a process and capture logs in real-time to yield them."""
        yield self.log(
            f"Running {fn.__name__}({', '.join(f'{k}={v}' for k, v in kwargs.items())})"
        )
        logs_queue, stdout_queue, stderr_queue, error_queue, wrapped_fn = wrap_for_process(fn, log_level=log_level, logger_name=logger_name)
        self.process = Process(target=wrapped_fn, kwargs=kwargs)

        # Start process and pull logs while it runs
        self.process.start()
        while self.process.is_alive():
            yield from self._log_from_queue(logs_queue)
            yield from self._log_from_queue(stdout_queue)
            yield from self._log_from_queue(stderr_queue)
            self.process.join(timeout=0.1)

        # After the process completes, yield any remaining logs
        yield from self._log_from_queue(logs_queue)
        yield from self._log_from_queue(stdout_queue)
        yield from self._log_from_queue(stderr_queue)

        # Check for error
        try:
            error_msg = error_queue.get_nowait()
            self.exit_code = 1
            yield self.log(error_msg, level="ERROR")            
        except queue.Empty:
            yield self.log("Process completed successfully")
            self.exit_code = 0

    def __repr__(self) -> str:
        return f"<LogsViewRunner nb_logs={len(self.logs)} exit_code={self.exit_code}>"

    def __del__(self):
        if (isinstance(self.process, Process) and self.process.is_alive()) or (isinstance(self.process, subprocess.Popen) and self.process.poll() is None):
            try:
                print(f"Terminating process {self.process}")
                self.process.terminate()
            except Exception as e:
                print(f"Failed to terminate process: {e}")
            finally:
                print(f"Killing process: {self.process}")
                self.process.kill()

class LogsView(Component):
    """
    Creates a component to visualize logs from a subprocess in real-time.
    """

    EVENTS = [
        Events.change,
        Events.input,
        Events.focus,
        Events.blur,
    ]

    def __init__(
        self,
        value: str | Callable | tuple[str] | None = None,
        *,
        every: float | None = None,
        lines: int = 5,
        label: str | None = None,
        show_label: bool | None = None,
        container: bool = True,
        scale: int | None = None,
        min_width: int = 160,
        visible: bool = True,
        elem_id: str | None = None,
        elem_classes: list[str] | str | None = None,
        render: bool = True,
    ):
        """
        Parameters:
            value: Default value to show in the code editor. If callable, the function will be called whenever the app loads to set the initial value of the component.
            every: If `value` is a callable, run the function 'every' number of seconds while the client connection is open. Has no effect otherwise. The event can be accessed (e.g. to cancel it) via this component's .load_event attribute.
            label: The label for this component. Appears above the component and is also used as the header if there are a table of examples for this component. If None and used in a `gr.Interface`, the label will be the name of the parameter this component is assigned to.
            show_label: if True, will display label.
            container: If True, will place the component in a container - providing some extra padding around the border.
            scale: relative size compared to adjacent Components. For example if Components A and B are in a Row, and A has scale=2, and B has scale=1, A will be twice as wide as B. Should be an integer. scale applies in Rows, and to top-level Components in Blocks where fill_height=True.
            min_width: minimum pixel width, will wrap if not sufficient screen space to satisfy this value. If a certain scale value results in this Component being narrower than min_width, the min_width parameter will be respected first.
            visible: If False, component will be hidden.
            elem_id: An optional string that is assigned as the id of this component in the HTML DOM. Can be used for targeting CSS styles.
            elem_classes: An optional list of strings that are assigned as the classes of this component in the HTML DOM. Can be used for targeting CSS styles.
            render: If False, component will not render be rendered in the Blocks context. Should be used if the intention is to assign event listeners now but render the component later.
        """
        self.language = "shell"
        self.lines = lines
        self.interactive = False
        super().__init__(
            label=label,
            every=every,
            show_label=show_label,
            container=container,
            scale=scale,
            min_width=min_width,
            visible=visible,
            elem_id=elem_id,
            elem_classes=elem_classes,
            render=render,
            value=value,
        )

    def preprocess(self, payload: str | None) -> NoReturn:
        """
        Parameters:
            payload: string corresponding to the code
        Returns:
            Passes the code entered as a `str`.
        """
        raise NotImplementedError("LogsView cannot be used as an input component.")

    def postprocess(self, value: List[Log]) -> List[Log]:
        """
        Parameters:
            value: Expects a list of `Log` logs.
        Returns:
            Returns the list of `Log` logs.
        """
        return value

    def api_info(self) -> dict[str, Any]:
        return {
            "items": {"level": "string", "message": "string", "timestamp": "number"},
            "title": "Logs",
            "type": "array",
        }

    def example_payload(self) -> Any:
        return [Log("INFO", "Hello World", datetime.now().isoformat())]

    def example_value(self) -> Any:
        return [Log("INFO", "Hello World", datetime.now().isoformat())]


@contextmanager
def capture_logging(log_queue: mpQueue, log_level: int, logger_name: str | None = None) -> Generator:
    # Create a queue to capture log messages
    logger = logging.getLogger(logger_name)
    logger.setLevel(log_level)
    handler = QueueHandler(log_queue)
    logger.addHandler(handler)

    yield

    # Clean up
    logger.removeHandler(handler)


def wrap_for_process(fn: Callable, log_level: int, logger_name: str | None) -> Callable:
    logs_queue = mpQueue()
    stdout_queue = mpQueue()
    stderr_queue = mpQueue()
    error_queue = mpQueue()

    @wraps(fn)
    def _inner(*args, **kwargs):
        with capture_logging(logs_queue, log_level, logger_name):
            with redirect_stdout(CapturingStream(stdout_queue)):
                with redirect_stderr(CapturingStream(stderr_queue)):
                        try:
                            fn(*args, **kwargs)
                        except Exception as error:
                            msg = (
                                f"Error in '{fn.__name__}':"
                                + "\n"
                                + "\n".join(
                                    line.strip("\n")
                                    for line in traceback.format_tb(error.__traceback__)
                                    if line.strip()
                                )
                                + "\n\n"
                                + str(error)
                            )
                            error_queue.put(msg)

    return logs_queue, stdout_queue, stderr_queue, error_queue, _inner

class CapturingStream(io.StringIO):
    """Stream to capture stdout/stderr line by line and put them in a queue."""
    def __init__(self, queue: mpQueue, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._queue = queue
        self._current_line = ""

    def write(self, s: str) -> int:
        s = s.replace("\r", "\n") # Remove carriage return (from tqdm)
        if "\n" in s:
            lines = s.split("\n")
            for line in lines[:-1]:
                self._current_line += line
                self._queue.put(self._current_line)
                self._current_line = ""
            self._current_line += lines[-1]
        else:
            self._current_line += s
        return super().write(s)
