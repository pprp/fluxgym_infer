import { E as q, C as D, L as A } from "./index-2ee8fec2.js";
import { s as N, t as n, a as L, i as H, L as B, b as K, d as X, f as M, c as OO, e as aO, I as eO, g as iO, N as nO, h as o } from "./Index-d65e8fec.js";
const rO = 1, G = 194, w = 195, QO = 196, v = 197, tO = 198, oO = 199, dO = 200, sO = 2, E = 3, k = 201, TO = 24, lO = 25, SO = 49, pO = 50, hO = 55, PO = 56, mO = 57, $O = 59, gO = 60, qO = 61, cO = 62, XO = 63, fO = 65, _O = 238, RO = 71, yO = 241, WO = 242, zO = 243, vO = 244, kO = 245, bO = 246, uO = 247, xO = 248, Z = 72, UO = 249, VO = 250, GO = 251, wO = 252, EO = 253, ZO = 254, jO = 255, YO = 256, FO = 73, JO = 77, CO = 264, IO = 112, DO = 130, AO = 151, NO = 152, LO = 155, p = 10, h = 13, W = 32, c = 9, z = 35, HO = 40, BO = 46, y = 123, b = 125, j = 39, Y = 34, KO = 92, MO = 111, Oa = 120, aa = 78, ea = 117, ia = 85, na = /* @__PURE__ */ new Set([
  lO,
  SO,
  pO,
  CO,
  fO,
  DO,
  PO,
  mO,
  _O,
  cO,
  XO,
  Z,
  FO,
  JO,
  gO,
  qO,
  AO,
  NO,
  LO,
  IO
]);
function f(O) {
  return O == p || O == h;
}
function _(O) {
  return O >= 48 && O <= 57 || O >= 65 && O <= 70 || O >= 97 && O <= 102;
}
const ra = new q((O, e) => {
  let a;
  if (O.next < 0)
    O.acceptToken(oO);
  else if (e.context.flags & $)
    f(O.next) && O.acceptToken(tO, 1);
  else if (((a = O.peek(-1)) < 0 || f(a)) && e.canShift(v)) {
    let i = 0;
    for (; O.next == W || O.next == c; )
      O.advance(), i++;
    (O.next == p || O.next == h || O.next == z) && O.acceptToken(v, -i);
  } else
    f(O.next) && O.acceptToken(QO, 1);
}, { contextual: !0 }), Qa = new q((O, e) => {
  let a = e.context;
  if (a.flags)
    return;
  let i = O.peek(-1);
  if (i == p || i == h) {
    let r = 0, S = 0;
    for (; ; ) {
      if (O.next == W)
        r++;
      else if (O.next == c)
        r += 8 - r % 8;
      else
        break;
      O.advance(), S++;
    }
    r != a.indent && O.next != p && O.next != h && O.next != z && (r < a.indent ? O.acceptToken(w, -S) : O.acceptToken(G));
  }
}), $ = 1, F = 2, d = 4, s = 8, T = 16, l = 32;
function g(O, e, a) {
  this.parent = O, this.indent = e, this.flags = a, this.hash = (O ? O.hash + O.hash << 8 : 0) + e + (e << 4) + a + (a << 6);
}
const ta = new g(null, 0, 0);
function oa(O) {
  let e = 0;
  for (let a = 0; a < O.length; a++)
    e += O.charCodeAt(a) == c ? 8 - e % 8 : 1;
  return e;
}
const u = new Map([
  [yO, 0],
  [WO, d],
  [zO, s],
  [vO, s | d],
  [kO, T],
  [bO, T | d],
  [uO, T | s],
  [xO, T | s | d],
  [UO, l],
  [VO, l | d],
  [GO, l | s],
  [wO, l | s | d],
  [EO, l | T],
  [ZO, l | T | d],
  [jO, l | T | s],
  [YO, l | T | s | d]
].map(([O, e]) => [O, e | F])), da = new D({
  start: ta,
  reduce(O, e, a, i) {
    return O.flags & $ && na.has(e) || (e == RO || e == Z) && O.flags & F ? O.parent : O;
  },
  shift(O, e, a, i) {
    return e == G ? new g(O, oa(i.read(i.pos, a.pos)), 0) : e == w ? O.parent : e == TO || e == hO || e == $O || e == E ? new g(O, 0, $) : u.has(e) ? new g(O, 0, u.get(e) | O.flags & $) : O;
  },
  hash(O) {
    return O.hash;
  }
}), sa = new q((O) => {
  for (let e = 0; e < 5; e++) {
    if (O.next != "print".charCodeAt(e))
      return;
    O.advance();
  }
  if (!/\w/.test(String.fromCharCode(O.next)))
    for (let e = 0; ; e++) {
      let a = O.peek(e);
      if (!(a == W || a == c)) {
        a != HO && a != BO && a != p && a != h && a != z && O.acceptToken(rO);
        return;
      }
    }
}), Ta = new q((O, e) => {
  let { flags: a } = e.context, i = a & d ? Y : j, r = (a & s) > 0, S = !(a & T), Q = (a & l) > 0, t = O.pos;
  for (; !(O.next < 0); )
    if (Q && O.next == y)
      if (O.peek(1) == y)
        O.advance(2);
      else {
        if (O.pos == t) {
          O.acceptToken(E, 1);
          return;
        }
        break;
      }
    else if (S && O.next == KO) {
      if (O.pos == t) {
        O.advance();
        let P = O.next;
        P >= 0 && (O.advance(), la(O, P)), O.acceptToken(sO);
        return;
      }
      break;
    } else if (O.next == i && (!r || O.peek(1) == i && O.peek(2) == i)) {
      if (O.pos == t) {
        O.acceptToken(k, r ? 3 : 1);
        return;
      }
      break;
    } else if (O.next == p) {
      if (r)
        O.advance();
      else if (O.pos == t) {
        O.acceptToken(k);
        return;
      }
      break;
    } else
      O.advance();
  O.pos > t && O.acceptToken(dO);
});
function la(O, e) {
  if (e == MO)
    for (let a = 0; a < 2 && O.next >= 48 && O.next <= 55; a++)
      O.advance();
  else if (e == Oa)
    for (let a = 0; a < 2 && _(O.next); a++)
      O.advance();
  else if (e == ea)
    for (let a = 0; a < 4 && _(O.next); a++)
      O.advance();
  else if (e == ia)
    for (let a = 0; a < 8 && _(O.next); a++)
      O.advance();
  else if (e == aa && O.next == y) {
    for (O.advance(); O.next >= 0 && O.next != b && O.next != j && O.next != Y && O.next != p; )
      O.advance();
    O.next == b && O.advance();
  }
}
const Sa = N({
  'async "*" "**" FormatConversion FormatSpec': n.modifier,
  "for while if elif else try except finally return raise break continue with pass assert await yield match case": n.controlKeyword,
  "in not and or is del": n.operatorKeyword,
  "from def class global nonlocal lambda": n.definitionKeyword,
  import: n.moduleKeyword,
  "with as print": n.keyword,
  Boolean: n.bool,
  None: n.null,
  VariableName: n.variableName,
  "CallExpression/VariableName": n.function(n.variableName),
  "FunctionDefinition/VariableName": n.function(n.definition(n.variableName)),
  "ClassDefinition/VariableName": n.definition(n.className),
  PropertyName: n.propertyName,
  "CallExpression/MemberExpression/PropertyName": n.function(n.propertyName),
  Comment: n.lineComment,
  Number: n.number,
  String: n.string,
  FormatString: n.special(n.string),
  Escape: n.escape,
  UpdateOp: n.updateOperator,
  "ArithOp!": n.arithmeticOperator,
  BitOp: n.bitwiseOperator,
  CompareOp: n.compareOperator,
  AssignOp: n.definitionOperator,
  Ellipsis: n.punctuation,
  At: n.meta,
  "( )": n.paren,
  "[ ]": n.squareBracket,
  "{ }": n.brace,
  ".": n.derefOperator,
  ", ;": n.separator
}), pa = { __proto__: null, await: 44, or: 54, and: 56, in: 60, not: 62, is: 64, if: 70, else: 72, lambda: 76, yield: 94, from: 96, async: 102, for: 104, None: 162, True: 164, False: 164, del: 178, pass: 182, break: 186, continue: 190, return: 194, raise: 202, import: 206, as: 208, global: 212, nonlocal: 214, assert: 218, type: 223, elif: 236, while: 240, try: 246, except: 248, finally: 250, with: 254, def: 258, class: 268, match: 279, case: 285 }, ha = A.deserialize({
  version: 14,
  states: "##pO`QeOOP$}OSOOO&WQtO'#HUOOQS'#Co'#CoOOQS'#Cp'#CpO'vQdO'#CnO*UQtO'#HTOOQS'#HU'#HUOOQS'#DU'#DUOOQS'#HT'#HTO*rQdO'#D_O+VQdO'#DfO+gQdO'#DjO+zOWO'#DuO,VOWO'#DvO.[QtO'#GuOOQS'#Gu'#GuO'vQdO'#GtO0ZQtO'#GtOOQS'#Eb'#EbO0rQdO'#EcOOQS'#Gs'#GsO0|QdO'#GrOOQV'#Gr'#GrO1XQdO'#FYOOQS'#G^'#G^O1^QdO'#FXOOQV'#IS'#ISOOQV'#Gq'#GqOOQV'#Fq'#FqQ`QeOOO'vQdO'#CqO1lQdO'#C}O1sQdO'#DRO2RQdO'#HYO2cQtO'#EVO'vQdO'#EWOOQS'#EY'#EYOOQS'#E['#E[OOQS'#E^'#E^O2wQdO'#E`O3_QdO'#EdO1XQdO'#EfO3rQtO'#EfO1XQdO'#EiO0rQdO'#ElO1XQdO'#EnO0rQdO'#EtO0rQdO'#EwO3}QdO'#EyO4UQdO'#FOO4aQdO'#EzO0rQdO'#FOO1XQdO'#FQO1XQdO'#FVO4fQdO'#F[P4mOdO'#GpPOOO)CBd)CBdOOQS'#Ce'#CeOOQS'#Cf'#CfOOQS'#Cg'#CgOOQS'#Ch'#ChOOQS'#Ci'#CiOOQS'#Cj'#CjOOQS'#Cl'#ClO'vQdO,59OO'vQdO,59OO'vQdO,59OO'vQdO,59OO'vQdO,59OO'vQdO,59OO4xQdO'#DoOOQS,5:Y,5:YO5]QdO'#HdOOQS,5:],5:]O5jQ!fO,5:]O5oQtO,59YO1lQdO,59bO1lQdO,59bO1lQdO,59bO8_QdO,59bO8dQdO,59bO8kQdO,59jO8rQdO'#HTO9xQdO'#HSOOQS'#HS'#HSOOQS'#D['#D[O:aQdO,59aO'vQdO,59aO:oQdO,59aOOQS,59y,59yO:tQdO,5:RO'vQdO,5:ROOQS,5:Q,5:QO;SQdO,5:QO;XQdO,5:XO'vQdO,5:XO'vQdO,5:VOOQS,5:U,5:UO;jQdO,5:UO;oQdO,5:WOOOW'#Fy'#FyO;tOWO,5:aOOQS,5:a,5:aO<PQdO'#HwOOOW'#Dw'#DwOOOW'#Fz'#FzO<aOWO,5:bOOQS,5:b,5:bOOQS'#F}'#F}O<oQtO,5:iO?aQtO,5=`O?zQ#xO,5=`O@kQtO,5=`OOQS,5:},5:}OASQeO'#GWOBfQdO,5;^OOQV,5=^,5=^OBqQtO'#H}OCYQdO,5;tOOQS-E:[-E:[OOQV,5;s,5;sO4[QdO'#FQOOQV-E9o-E9oOCbQtO,59]OEiQtO,59iOFSQdO'#HVOF_QdO'#HVO1XQdO'#HVOFjQdO'#DTOFrQdO,59mOFwQdO'#HZO'vQdO'#HZO0rQdO,5=tOOQS,5=t,5=tO0rQdO'#EROOQS'#ES'#ESOGfQdO'#GPOGvQdO,58|OGvQdO,58|O*xQdO,5:oOHUQtO'#H]OOQS,5:r,5:rOOQS,5:z,5:zOHiQdO,5;OOHzQdO,5;QOOQS'#GS'#GSOIYQtO,5;QOIhQdO,5;QOImQdO'#IQOOQS,5;T,5;TOI{QdO'#H|OOQS,5;W,5;WOJ^QdO,5;YO4aQdO,5;`O4aQdO,5;cOJfQtO'#ITO'vQdO'#ITOJpQdO,5;eO3}QdO,5;eO0rQdO,5;jO1XQdO,5;lOJuQeO'#EuOLRQgO,5;fO!!SQdO'#IUO4aQdO,5;jO!!_QdO,5;lO!!gQdO,5;qO!!rQtO,5;vO'vQdO,5;vPOOO,5=[,5=[P!!yOSO,5=[P!#OOdO,5=[O!%sQtO1G.jO!%zQtO1G.jO!(kQtO1G.jO!(uQtO1G.jO!+`QtO1G.jO!+sQtO1G.jO!,WQdO'#HcO!,fQtO'#GuO0rQdO'#HcO!,pQdO'#HbOOQS,5:Z,5:ZO!,xQdO,5:ZO!,}QdO'#HeO!-YQdO'#HeO!-mQdO,5>OOOQS'#Ds'#DsOOQS1G/w1G/wOOQS1G.|1G.|O!.mQtO1G.|O!.tQtO1G.|O1lQdO1G.|O!/aQdO1G/UOOQS'#DZ'#DZO0rQdO,59tOOQS1G.{1G.{O!/hQdO1G/eO!/xQdO1G/eO!0QQdO1G/fO'vQdO'#H[O!0VQdO'#H[O!0[QtO1G.{O!0lQdO,59iO!1rQdO,5=zO!2SQdO,5=zO!2[QdO1G/mO!2aQtO1G/mOOQS1G/l1G/lO!2qQdO,5=uO!3hQdO,5=uO0rQdO1G/qO!4VQdO1G/sO!4[QtO1G/sO!4lQtO1G/qOOQS1G/p1G/pOOQS1G/r1G/rOOOW-E9w-E9wOOQS1G/{1G/{O!4|QdO'#HxO0rQdO'#HxO!5_QdO,5>cOOOW-E9x-E9xOOQS1G/|1G/|OOQS-E9{-E9{O!5mQ#xO1G2zO!6^QtO1G2zO'vQdO,5<jOOQS,5<j,5<jOOQS-E9|-E9|OOQS,5<r,5<rOOQS-E:U-E:UOOQV1G0x1G0xO1XQdO'#GRO!6uQtO,5>iOOQS1G1`1G1`O!7^QdO1G1`OOQS'#DV'#DVO0rQdO,5=qOOQS,5=q,5=qO!7cQdO'#FrO!7nQdO,59oO!7vQdO1G/XO!8QQtO,5=uOOQS1G3`1G3`OOQS,5:m,5:mO!8qQdO'#GtOOQS,5<k,5<kOOQS-E9}-E9}O!9SQdO1G.hOOQS1G0Z1G0ZO!9bQdO,5=wO!9rQdO,5=wO0rQdO1G0jO0rQdO1G0jO1XQdO1G0lOOQS-E:Q-E:QO!:TQdO1G0lO!:`QdO1G0lO!:eQdO,5>lO!:sQdO,5>lO!;RQdO,5>hO!;iQdO,5>hO!;zQdO'#EpO0rQdO1G0tO!<VQdO1G0tO!<[QgO1G0zO!@YQgO1G0}O!DTQdO,5>oO!D_QdO,5>oO!DgQtO,5>oO0rQdO1G1PO!DqQdO1G1PO4aQdO1G1UO!!_QdO1G1WOOQV,5;a,5;aO!DvQfO,5;aO!D{QgO1G1QO!H|QdO'#GZO4aQdO1G1QO4aQdO1G1QO!I^QdO,5>pO!IkQdO,5>pO1XQdO,5>pOOQV1G1U1G1UO!IsQdO'#FSO!JUQ!fO1G1WO!J^QdO1G1WOOQV1G1]1G1]O4aQdO1G1]O!JcQdO1G1]O!JkQdO'#F^OOQV1G1b1G1bO!!rQtO1G1bPOOO1G2v1G2vP!JpOSO1G2vOOQS,5=},5=}OOQS'#Dp'#DpO0rQdO,5=}O!JuQdO,5=|O!KYQdO,5=|OOQS1G/u1G/uO!KbQdO,5>PO!KrQdO,5>PO!KzQdO,5>PO!L_QdO,5>PO!LoQdO,5>POOQS1G3j1G3jOOQS7+$h7+$hO!7vQdO7+$pO!NbQdO1G.|O!NiQdO1G.|OOQS1G/`1G/`OOQS,5<`,5<`O'vQdO,5<`OOQS7+%P7+%PO!NpQdO7+%POOQS-E9r-E9rOOQS7+%Q7+%QO# QQdO,5=vO'vQdO,5=vOOQS7+$g7+$gO# VQdO7+%PO# _QdO7+%QO# dQdO1G3fOOQS7+%X7+%XO# tQdO1G3fO# |QdO7+%XOOQS,5<_,5<_O'vQdO,5<_O#!RQdO1G3aOOQS-E9q-E9qO#!xQdO7+%]OOQS7+%_7+%_O##WQdO1G3aO##uQdO7+%_O##zQdO1G3gO#$[QdO1G3gO#$dQdO7+%]O#$iQdO,5>dO#%SQdO,5>dO#%SQdO,5>dOOQS'#Dx'#DxO#%eO&jO'#DzO#%pO`O'#HyOOOW1G3}1G3}O#%uQdO1G3}O#%}QdO1G3}O#&YQ#xO7+(fO#&yQtO1G2UP#'dQdO'#GOOOQS,5<m,5<mOOQS-E:P-E:POOQS7+&z7+&zOOQS1G3]1G3]OOQS,5<^,5<^OOQS-E9p-E9pOOQS7+$s7+$sO#'qQdO,5=`O#([QdO,5=`O#(mQtO,5<aO#)QQdO1G3cOOQS-E9s-E9sOOQS7+&U7+&UO#)bQdO7+&UOOQS7+&W7+&WO#)pQdO'#IPO1XQdO'#IOO#*UQdO7+&WOOQS,5<p,5<pO#*aQdO1G4WOOQS-E:S-E:SOOQS,5<l,5<lO#*oQdO1G4SOOQS-E:O-E:OO1XQdO'#EqO#+VQdO'#EqO#+bQdO'#IRO#+jQdO,5;[OOQS7+&`7+&`O0rQdO7+&`O#+oQgO7+&fO!IPQdO'#GXO4aQdO7+&fO4aQdO7+&iO#/mQtO,5<tO'vQdO,5<tO#/wQdO1G4ZOOQS-E:W-E:WO#0RQdO1G4ZO4aQdO7+&kO0rQdO7+&kOOQV7+&p7+&pO!JUQ!fO7+&rO!J^QdO7+&rO`QeO1G0{OOQV-E:X-E:XO4aQdO7+&lO4aQdO7+&lOOQV,5<u,5<uO#0ZQdO,5<uO!IPQdO,5<uOOQV7+&l7+&lO#0fQgO7+&lO#4aQdO,5<vO#4lQdO1G4[OOQS-E:Y-E:YO#4yQdO1G4[O#5RQdO'#IWO#5aQdO'#IWO1XQdO'#IWOOQS'#IW'#IWO#5lQdO'#IVOOQS,5;n,5;nO#5tQdO,5;nO0rQdO'#FUOOQV7+&r7+&rO4aQdO7+&rOOQV7+&w7+&wO4aQdO7+&wO#5yQfO,5;xOOQV7+&|7+&|POOO7+(b7+(bO#6OQdO1G3iOOQS,5<c,5<cO#6^QdO1G3hOOQS-E9u-E9uO#6qQdO,5<dO#6|QdO,5<dO#7aQdO1G3kOOQS-E9v-E9vO#7qQdO1G3kO#7yQdO1G3kO#8ZQdO1G3kO#7qQdO1G3kOOQS<<H[<<H[O#8fQtO1G1zOOQS<<Hk<<HkP#8sQdO'#FtO8kQdO1G3bO#9QQdO1G3bO#9VQdO<<HkOOQS<<Hl<<HlO#9gQdO7+)QOOQS<<Hs<<HsO#9wQtO1G1yP#:hQdO'#FsO#:uQdO7+)RO#;VQdO7+)RO#;_QdO<<HwO#;dQdO7+({OOQS<<Hy<<HyO#<ZQdO,5<bO'vQdO,5<bOOQS-E9t-E9tOOQS<<Hw<<HwOOQS,5<g,5<gO0rQdO,5<gO#<`QdO1G4OOOQS-E9y-E9yO#<yQdO1G4OO<PQdO'#H{OOOO'#D{'#D{OOOO'#F|'#F|O#=[O&jO,5:fOOOW,5>e,5>eOOOW7+)i7+)iO#=gQdO7+)iO#=oQdO1G2zO#>YQdO1G2zP'vQdO'#FuO0rQdO<<IpO#>kQdO,5>kO#>|QdO,5>kO1XQdO,5>kO#?_QdO,5>jOOQS<<Ir<<IrP1XQdO'#GUP0rQdO'#GQOOQS,5;],5;]O#?dQdO,5>mO#?rQdO,5>mOOQS1G0v1G0vOOQS<<Iz<<IzOOQV-E:V-E:VO4aQdO<<JQOOQV,5<s,5<sO4aQdO,5<sOOQV<<JQ<<JQOOQV<<JT<<JTO#?zQtO1G2`P#@UQdO'#GYO#@]QdO7+)uO#@gQgO<<JVO4aQdO<<JVOOQV<<J^<<J^O4aQdO<<J^O!JUQ!fO<<J^O#DbQgO7+&gOOQV<<JW<<JWO#DlQgO<<JWOOQV1G2a1G2aO1XQdO1G2aO#HgQdO1G2aO4aQdO<<JWO1XQdO1G2bP0rQdO'#G[O#HrQdO7+)vO#IPQdO7+)vOOQS'#FT'#FTO0rQdO,5>rO#IXQdO,5>rOOQS,5>r,5>rO#IdQdO,5>qO#IuQdO,5>qOOQS1G1Y1G1YOOQS,5;p,5;pOOQV<<Jc<<JcO#I}QdO1G1dOOQS7+)T7+)TP#JSQdO'#FwO#JdQdO1G2OO#JwQdO1G2OO#KXQdO1G2OP#KdQdO'#FxO#KqQdO7+)VO#LRQdO7+)VO#LRQdO7+)VO#LZQdO7+)VO#LkQdO7+(|O8kQdO7+(|OOQSAN>VAN>VO#MUQdO<<LmOOQSAN>cAN>cO0rQdO1G1|O#MfQtO1G1|P#MpQdO'#FvOOQS1G2R1G2RP#M}QdO'#F{O#N[QdO7+)jO#NuQdO,5>gOOOO-E9z-E9zOOOW<<MT<<MTO$ TQdO7+(fOOQSAN?[AN?[O$ nQdO,5<oO$!SQdO1G4VOOQS-E:R-E:RO$!eQdO1G4VOOQS1G4U1G4UOOQS,5<q,5<qO$!vQdO1G4XOOQS-E:T-E:TOOQVAN?lAN?lOOQV1G2_1G2_O4aQdOAN?qO$#UQgOAN?qOOQVAN?xAN?xO4aQdOAN?xOOQV<<JR<<JRO4aQdOAN?rO4aQdO7+'{OOQV7+'{7+'{O1XQdO7+'{OOQVAN?rAN?rOOQS7+'|7+'|O$'PQdO<<MbOOQS1G4^1G4^O0rQdO1G4^OOQS,5<w,5<wO$'^QdO1G4]OOQS-E:Z-E:ZOOQU'#G_'#G_O$'oQfO7+'OO$'zQdO'#F_O$)RQdO7+'jO$)cQdO7+'jOOQS7+'j7+'jO$)nQdO<<LqO$*OQdO<<LqO$*OQdO<<LqO$*WQdO'#H^OOQS<<Lh<<LhO$*bQdO<<LhOOQS7+'h7+'hOOQS'#D|'#D|OOOO1G4R1G4RO$*{QdO1G4RO$+TQdO1G4RO1XQdO1G2ZP1XQdO'#GTO$+`QdO7+)qO$+qQdO7+)qP!;zQdO'#GVOOQVG25]G25]O4aQdOG25]OOQVG25dG25dOOQVG25^G25^OOQV<<Kg<<KgO4aQdO<<KgOOQS7+)x7+)xP$,SQdO'#G]OOQU-E:]-E:]OOQV<<Jj<<JjO$,vQtO'#FaOOQS'#Fc'#FcO$-WQdO'#FbO$-xQdO'#FbOOQS'#Fb'#FbO$-}QdO'#IYO$'zQdO'#FiO$'zQdO'#FiO$.fQdO'#FjO$'zQdO'#FkO$.mQdO'#IZOOQS'#IZ'#IZO$/[QdO,5;yOOQS<<KU<<KUO$/dQdO<<KUO$/tQdOANB]O$0UQdOANB]O$0^QdO'#H_OOQS'#H_'#H_O1sQdO'#DcO$0wQdO,5=xOOQSANBSANBSOOOO7+)m7+)mO$1`QdO7+)mOOQS7+'u7+'uO$1hQdO<<M]OOQVLD*wLD*wOOQVANARANARO5jQ!fO'#GaO$1yQtO,5<SO$'zQdO'#FmOOQS,5<W,5<WOOQS'#Fd'#FdO$2kQdO,5;|O$2pQdO,5;|OOQS'#Fg'#FgO$'zQdO'#G`O$3bQdO,5<QO$3|QdO,5>tO$4^QdO,5>tO1XQdO,5<PO$4oQdO,5<TO$4tQdO,5<TO$'zQdO'#I[O$4yQdO'#I[O$5OQdO,5<UOOQS,5<V,5<VO'vQdO'#FpOOQU1G1e1G1eO4aQdO1G1eOOQSAN@pAN@pO$5TQdOG27wO$5eQdO,59}OOQS1G3d1G3dOOOO<<MX<<MXOOQS,5<{,5<{OOQS-E:_-E:_O$5jQtO'#FaO$5qQdO'#I]O$6PQdO'#I]O$6XQdO,5<XOOQS1G1h1G1hO$6^QdO1G1hO$6cQdO,5<zOOQS-E:^-E:^O$6}QdO,5=OO$7fQdO1G4`OOQS-E:b-E:bOOQS1G1k1G1kOOQS1G1o1G1oO$7vQdO,5>vO$'zQdO,5>vOOQS1G1p1G1pO$8UQtO,5<[OOQU7+'P7+'PO$*WQdO1G/iO$'zQdO,5<YO$8]QdO,5>wO$8dQdO,5>wOOQS1G1s1G1sOOQS7+'S7+'SP$'zQdO'#GdO$8lQdO1G4bO$8vQdO1G4bO$9OQdO1G4bOOQS7+%T7+%TO$9^QdO1G1tO$9lQtO'#FaO$9sQdO,5<}OOQS,5<},5<}O$:RQdO1G4cOOQS-E:a-E:aO$'zQdO,5<|O$:YQdO,5<|O$:_QdO7+)|OOQS-E:`-E:`O$:iQdO7+)|O$'zQdO,5<ZP$'zQdO'#GcO$:qQdO1G2hO$'zQdO1G2hP$;PQdO'#GbO$;WQdO<<MhO$;bQdO1G1uO$;pQdO7+(SO8kQdO'#C}O8kQdO,59bO8kQdO,59bO8kQdO,59bO$<OQtO,5=`O8kQdO1G.|O0rQdO1G/XO0rQdO7+$pP$<cQdO'#GOO'vQdO'#GtO$<pQdO,59bO$<uQdO,59bO$<|QdO,59mO$=RQdO1G/UO1sQdO'#DRO8kQdO,59j",
  stateData: "$=l~O%cOS%^OSSOS%]PQ~OPdOVaOfoOhYOopOs!POvqO!PrO!Q{O!T!SO!U!RO!XZO!][O!h`O!r`O!s`O!t`O!{tO!}uO#PvO#RwO#TxO#XyO#ZzO#^|O#_|O#a}O#c!OO#l!QO#o!TO#s!UO#u!VO#z!WO#}hO$P!XO%oRO%pRO%tSO%uWO&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O&c^O&d^O&e^O&f^O&g^O&h^O&i^O&j^O~O%]!YO~OV!aO_!aOa!bOh!iO!X!kO!f!mO%j![O%k!]O%l!^O%m!_O%n!_O%o!`O%p!`O%q!aO%r!aO%s!aO~Ok%xXl%xXm%xXn%xXo%xXp%xXs%xXz%xX{%xX!x%xX#g%xX%[%xX%_%xX%z%xXg%xX!T%xX!U%xX%{%xX!W%xX![%xX!Q%xX#[%xXt%xX!m%xX~P%SOfoOhYO!XZO!][O!h`O!r`O!s`O!t`O%oRO%pRO%tSO%uWO&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O&c^O&d^O&e^O&f^O&g^O&h^O&i^O&j^O~Oz%wX{%wX#g%wX%[%wX%_%wX%z%wX~Ok!pOl!qOm!oOn!oOo!rOp!sOs!tO!x%wX~P)pOV!zOg!|Oo0dOv0rO!PrO~P'vOV#OOo0dOv0rO!W#PO~P'vOV#SOa#TOo0dOv0rO![#UO~P'vOQ#XO%`#XO%a#ZO~OQ#^OR#[O%`#^O%a#`O~OV%iX_%iXa%iXh%iXk%iXl%iXm%iXn%iXo%iXp%iXs%iXz%iX!X%iX!f%iX%j%iX%k%iX%l%iX%m%iX%n%iX%o%iX%p%iX%q%iX%r%iX%s%iXg%iX!T%iX!U%iX~O&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O&c^O&d^O&e^O&f^O&g^O&h^O&i^O&j^O{%iX!x%iX#g%iX%[%iX%_%iX%z%iX%{%iX!W%iX![%iX!Q%iX#[%iXt%iX!m%iX~P,eOz#dO{%hX!x%hX#g%hX%[%hX%_%hX%z%hX~Oo0dOv0rO~P'vO#g#gO%[#iO%_#iO~O%uWO~O!T#nO#u!VO#z!WO#}hO~OopO~P'vOV#sOa#tO%uWO{wP~OV#xOo0dOv0rO!Q#yO~P'vO{#{O!x$QO%z#|O#g!yX%[!yX%_!yX~OV#xOo0dOv0rO#g#SX%[#SX%_#SX~P'vOo0dOv0rO#g#WX%[#WX%_#WX~P'vO!f$WO!r$WO%uWO~OV$cO~P'vO!U$eO#s$fO#u$gO~O{$hO~OV$oO~P'vOS$qO%[$pO%c$rO~OV${Oa${Og$}Oo0dOv0rO~P'vOo0dOv0rO{%QO~P'vO&Y%SO~Oa!bOh!iO!X!kO!f!mOVba_bakbalbambanbaobapbasbazba{ba!xba#gba%[ba%_ba%jba%kba%lba%mba%nba%oba%pba%qba%rba%sba%zbagba!Tba!Uba%{ba!Wba![ba!Qba#[batba!mba~On%XO~Oo%XO~P'vOo0dO~P'vOk0fOl0gOm0eOn0eOo0nOp0oOs0sOg%wX!T%wX!U%wX%{%wX!W%wX![%wX!Q%wX#[%wX!m%wX~P)pO%{%ZOg%vXz%vX!T%vX!U%vX!W%vX{%vX~Og%]Oz%^O!T%bO!U%aO~Og%]O~Oz%eO!T%bO!U%aO!W&SX~O!W%iO~Oz%jO{%lO!T%bO!U%aO![%}X~O![%pO~O![%qO~OQ#XO%`#XO%a%sO~OV%uOo0dOv0rO!PrO~P'vOQ#^OR#[O%`#^O%a%xO~OV!qa_!qaa!qah!qak!qal!qam!qan!qao!qap!qas!qaz!qa{!qa!X!qa!f!qa!x!qa#g!qa%[!qa%_!qa%j!qa%k!qa%l!qa%m!qa%n!qa%o!qa%p!qa%q!qa%r!qa%s!qa%z!qag!qa!T!qa!U!qa%{!qa!W!qa![!qa!Q!qa#[!qat!qa!m!qa~P#yOz%zO{%ha!x%ha#g%ha%[%ha%_%ha%z%ha~P%SOV%|OopOvqO{%ha!x%ha#g%ha%[%ha%_%ha%z%ha~P'vOz%zO{%ha!x%ha#g%ha%[%ha%_%ha%z%ha~OPdOVaOopOvqO!PrO!Q{O!{tO!}uO#PvO#RwO#TxO#XyO#ZzO#^|O#_|O#a}O#c!OO#g$zX%[$zX%_$zX~P'vO#g#gO%[&RO%_&RO~O!f&SOh&qX%[&qX#[&qX#g&qX%_&qX#Z&qX~Oh!iO%[&UO~Okealeameaneaoeapeaseazea{ea!xea#gea%[ea%_ea%zeagea!Tea!Uea%{ea!Wea![ea!Qea#[eatea!mea~P%SOsqazqa{qa#gqa%[qa%_qa%zqa~Ok!pOl!qOm!oOn!oOo!rOp!sO!xqa~PEQO%z&WOz%yX{%yX~O%uWOz%yX{%yX~Oz&ZO{wX~O{&]O~Oz%jO#g%}X%[%}X%_%}Xg%}X{%}X![%}X!m%}X%z%}X~OV0mOo0dOv0rO!PrO~P'vO%z#|O#gUa%[Ua%_Ua~Oz&fO#g&PX%[&PX%_&PXn&PX~P%SOz&iO!Q&hO#g#Wa%[#Wa%_#Wa~O#[&jO#g#Ya%[#Ya%_#Ya~O!f$WO!r$WO#Z&lO%uWO~O#Z&lO~Oz&nO#g&tX%[&tX%_&tX~Oz&pO#g&pX%[&pX%_&pX{&pX~O!X&rO%z&sO~Oz&wOn&wX~P%SOn&zO~OPdOVaOopOvqO!PrO!Q{O!{tO!}uO#PvO#RwO#TxO#XyO#ZzO#^|O#_|O#a}O#c!OO%['PO~P'vOt'TO#p'RO#q'SOP#naV#naf#nah#nao#nas#nav#na!P#na!Q#na!T#na!U#na!X#na!]#na!h#na!r#na!s#na!t#na!{#na!}#na#P#na#R#na#T#na#X#na#Z#na#^#na#_#na#a#na#c#na#l#na#o#na#s#na#u#na#z#na#}#na$P#na%X#na%o#na%p#na%t#na%u#na&Z#na&[#na&]#na&^#na&_#na&`#na&a#na&b#na&c#na&d#na&e#na&f#na&g#na&h#na&i#na&j#na%Z#na%_#na~Oz'UO#['WO{&xX~Oh'YO!X&rO~Oh!iO{$hO!X&rO~O{'`O~P%SO%['cO~OS'dO%['cO~OV!aO_!aOa!bOh!iO!X!kO!f!mO%l!^O%m!_O%n!_O%o!`O%p!`O%q!aO%r!aO%s!aOkWilWimWinWioWipWisWizWi{Wi!xWi#gWi%[Wi%_Wi%jWi%zWigWi!TWi!UWi%{Wi!WWi![Wi!QWi#[WitWi!mWi~O%k!]O~P!#WO%kWi~P!#WOV!aO_!aOa!bOh!iO!X!kO!f!mO%o!`O%p!`O%q!aO%r!aO%s!aOkWilWimWinWioWipWisWizWi{Wi!xWi#gWi%[Wi%_Wi%jWi%kWi%lWi%zWigWi!TWi!UWi%{Wi!WWi![Wi!QWi#[WitWi!mWi~O%m!_O%n!_O~P!&RO%mWi%nWi~P!&ROa!bOh!iO!X!kO!f!mOkWilWimWinWioWipWisWizWi{Wi!xWi#gWi%[Wi%_Wi%jWi%kWi%lWi%mWi%nWi%oWi%pWi%zWigWi!TWi!UWi%{Wi!WWi![Wi!QWi#[WitWi!mWi~OV!aO_!aO%q!aO%r!aO%s!aO~P!)POVWi_Wi%qWi%rWi%sWi~P!)PO!T%bO!U%aOg&VXz&VX~O%z'fO%{'fO~P,eOz'hOg&UX~Og'jO~Oz'kO{'mO!W&XX~Oo0dOv0rOz'kO{'nO!W&XX~P'vO!W'pO~Om!oOn!oOo!rOp!sOkjisjizji{ji!xji#gji%[ji%_ji%zji~Ol!qO~P!-rOlji~P!-rOk0fOl0gOm0eOn0eOo0nOp0oO~Ot'rO~P!.{OV'wOg'xOo0dOv0rO~P'vOg'xOz'yO~Og'{O~O!U'}O~Og(OOz'yO!T%bO!U%aO~P%SOk0fOl0gOm0eOn0eOo0nOp0oOgqa!Tqa!Uqa%{qa!Wqa![qa!Qqa#[qatqa!mqa~PEQOV'wOo0dOv0rO!W&Sa~P'vOz(RO!W&Sa~O!W(SO~Oz(RO!T%bO!U%aO!W&Sa~P%SOV(WOo0dOv0rO![%}a#g%}a%[%}a%_%}ag%}a{%}a!m%}a%z%}a~P'vOz(XO![%}a#g%}a%[%}a%_%}ag%}a{%}a!m%}a%z%}a~O![([O~Oz(XO!T%bO!U%aO![%}a~P%SOz(_O!T%bO!U%aO![&Ta~P%SOz(bO{&lX![&lX!m&lX%z&lX~O{(fO![(hO!m(iO%z(eO~OV%|OopOvqO{%hi!x%hi#g%hi%[%hi%_%hi%z%hi~P'vOz(kO{%hi!x%hi#g%hi%[%hi%_%hi%z%hi~O!f&SOh&qa%[&qa#[&qa#g&qa%_&qa#Z&qa~O%[(pO~OV#sOa#tO%uWO~Oz&ZO{wa~OopOvqO~P'vOz(XO#g%}a%[%}a%_%}ag%}a{%}a![%}a!m%}a%z%}a~P%SOz(uO#g%hX%[%hX%_%hX%z%hX~O%z#|O#gUi%[Ui%_Ui~O#g&Pa%[&Pa%_&Pan&Pa~P'vOz(xO#g&Pa%[&Pa%_&Pan&Pa~OV(|Oh)OO%uWO~O#Z)PO~O%uWO#g&ta%[&ta%_&ta~Oz)RO#g&ta%[&ta%_&ta~Oo0dOv0rO#g&pa%[&pa%_&pa{&pa~P'vOz)UO#g&pa%[&pa%_&pa{&pa~OV)WOa)WO%uWO~O%z)]O~Ot)`O#j)_OP#hiV#hif#hih#hio#his#hiv#hi!P#hi!Q#hi!T#hi!U#hi!X#hi!]#hi!h#hi!r#hi!s#hi!t#hi!{#hi!}#hi#P#hi#R#hi#T#hi#X#hi#Z#hi#^#hi#_#hi#a#hi#c#hi#l#hi#o#hi#s#hi#u#hi#z#hi#}#hi$P#hi%X#hi%o#hi%p#hi%t#hi%u#hi&Z#hi&[#hi&]#hi&^#hi&_#hi&`#hi&a#hi&b#hi&c#hi&d#hi&e#hi&f#hi&g#hi&h#hi&i#hi&j#hi%Z#hi%_#hi~Ot)aOP#kiV#kif#kih#kio#kis#kiv#ki!P#ki!Q#ki!T#ki!U#ki!X#ki!]#ki!h#ki!r#ki!s#ki!t#ki!{#ki!}#ki#P#ki#R#ki#T#ki#X#ki#Z#ki#^#ki#_#ki#a#ki#c#ki#l#ki#o#ki#s#ki#u#ki#z#ki#}#ki$P#ki%X#ki%o#ki%p#ki%t#ki%u#ki&Z#ki&[#ki&]#ki&^#ki&_#ki&`#ki&a#ki&b#ki&c#ki&d#ki&e#ki&f#ki&g#ki&h#ki&i#ki&j#ki%Z#ki%_#ki~OV)cOn&wa~P'vOz)dOn&wa~Oz)dOn&wa~P%SOn)hO~O%Y)lO~Ot)oO#p'RO#q)nOP#niV#nif#nih#nio#nis#niv#ni!P#ni!Q#ni!T#ni!U#ni!X#ni!]#ni!h#ni!r#ni!s#ni!t#ni!{#ni!}#ni#P#ni#R#ni#T#ni#X#ni#Z#ni#^#ni#_#ni#a#ni#c#ni#l#ni#o#ni#s#ni#u#ni#z#ni#}#ni$P#ni%X#ni%o#ni%p#ni%t#ni%u#ni&Z#ni&[#ni&]#ni&^#ni&_#ni&`#ni&a#ni&b#ni&c#ni&d#ni&e#ni&f#ni&g#ni&h#ni&i#ni&j#ni%Z#ni%_#ni~OV)rOo0dOv0rO{$hO~P'vOo0dOv0rO{&xa~P'vOz)vO{&xa~OV)zOa){Og*OO%q)|O%uWO~O{$hO&{*QO~Oh'YO~Oh!iO{$hO~O%[*VO~O%[*XO~OV${Oa${Oo0dOv0rOg&Ua~P'vOz*[Og&Ua~Oo0dOv0rO{*_O!W&Xa~P'vOz*`O!W&Xa~Oo0dOv0rOz*`O{*cO!W&Xa~P'vOo0dOv0rOz*`O!W&Xa~P'vOz*`O{*cO!W&Xa~Om0eOn0eOo0nOp0oOgjikjisjizji!Tji!Uji%{ji!Wji{ji![ji#gji%[ji%_ji!Qji#[jitji!mji%zji~Ol0gO~P!LzOlji~P!LzOV'wOg*hOo0dOv0rO~P'vOn*jO~Og*hOz*lO~Og*mO~OV'wOo0dOv0rO!W&Si~P'vOz*nO!W&Si~O!W*oO~OV(WOo0dOv0rO![%}i#g%}i%[%}i%_%}ig%}i{%}i!m%}i%z%}i~P'vOz*rO!T%bO!U%aO![&Ti~Oz*uO![%}i#g%}i%[%}i%_%}ig%}i{%}i!m%}i%z%}i~O![*vO~Oa*xOo0dOv0rO![&Ti~P'vOz*rO![&Ti~O![*zO~OV*|Oo0dOv0rO{&la![&la!m&la%z&la~P'vOz*}O{&la![&la!m&la%z&la~O!]+QO&n+SO![!nX~O![+UO~O{(fO![+VO~O{(fO![+VO!m+WO~OV%|OopOvqO{%hq!x%hq#g%hq%[%hq%_%hq%z%hq~P'vOz$ri{$ri!x$ri#g$ri%[$ri%_$ri%z$ri~P%SOV%|OopOvqO~P'vOV%|Oo0dOv0rO#g%ha%[%ha%_%ha%z%ha~P'vOz+XO#g%ha%[%ha%_%ha%z%ha~Oz$ia#g$ia%[$ia%_$ian$ia~P%SO#g&Pi%[&Pi%_&Pin&Pi~P'vOz+[O#g#Wq%[#Wq%_#Wq~Oz+]O#[+_O#g&sX%[&sX%_&sXg&sX~OV+aOh)OO%uWO~O%uWO#g&ti%[&ti%_&ti~Oo0dOv0rO#g&pi%[&pi%_&pi{&pi~P'vO{#{Oz#eX!W#eX~Oz+eO!W&uX~O!W+gO~Ot+jO#j)_OP#hqV#hqf#hqh#hqo#hqs#hqv#hq!P#hq!Q#hq!T#hq!U#hq!X#hq!]#hq!h#hq!r#hq!s#hq!t#hq!{#hq!}#hq#P#hq#R#hq#T#hq#X#hq#Z#hq#^#hq#_#hq#a#hq#c#hq#l#hq#o#hq#s#hq#u#hq#z#hq#}#hq$P#hq%X#hq%o#hq%p#hq%t#hq%u#hq&Z#hq&[#hq&]#hq&^#hq&_#hq&`#hq&a#hq&b#hq&c#hq&d#hq&e#hq&f#hq&g#hq&h#hq&i#hq&j#hq%Z#hq%_#hq~On$|az$|a~P%SOV)cOn&wi~P'vOz+qOn&wi~Oz+{O{$hO#[+{O~O#q+}OP#nqV#nqf#nqh#nqo#nqs#nqv#nq!P#nq!Q#nq!T#nq!U#nq!X#nq!]#nq!h#nq!r#nq!s#nq!t#nq!{#nq!}#nq#P#nq#R#nq#T#nq#X#nq#Z#nq#^#nq#_#nq#a#nq#c#nq#l#nq#o#nq#s#nq#u#nq#z#nq#}#nq$P#nq%X#nq%o#nq%p#nq%t#nq%u#nq&Z#nq&[#nq&]#nq&^#nq&_#nq&`#nq&a#nq&b#nq&c#nq&d#nq&e#nq&f#nq&g#nq&h#nq&i#nq&j#nq%Z#nq%_#nq~O#[,OOz%Oa{%Oa~Oo0dOv0rO{&xi~P'vOz,QO{&xi~O{#{O%z,SOg&zXz&zX~O%uWOg&zXz&zX~Oz,WOg&yX~Og,YO~O%Y,]O~O!T%bO!U%aOg&Viz&Vi~OV${Oa${Oo0dOv0rOg&Ui~P'vO{,`Oz$la!W$la~Oo0dOv0rO{,aOz$la!W$la~P'vOo0dOv0rO{*_O!W&Xi~P'vOz,dO!W&Xi~Oo0dOv0rOz,dO!W&Xi~P'vOz,dO{,gO!W&Xi~Og$hiz$hi!W$hi~P%SOV'wOo0dOv0rO~P'vOn,iO~OV'wOg,jOo0dOv0rO~P'vOV'wOo0dOv0rO!W&Sq~P'vOz$gi![$gi#g$gi%[$gi%_$gig$gi{$gi!m$gi%z$gi~P%SOV(WOo0dOv0rO~P'vOa*xOo0dOv0rO![&Tq~P'vOz,kO![&Tq~O![,lO~OV(WOo0dOv0rO![%}q#g%}q%[%}q%_%}qg%}q{%}q!m%}q%z%}q~P'vO{,mO~OV*|Oo0dOv0rO{&li![&li!m&li%z&li~P'vOz,rO{&li![&li!m&li%z&li~O!]+QO&n+SO![!na~O{(fO![,uO~OV%|Oo0dOv0rO#g%hi%[%hi%_%hi%z%hi~P'vOz,vO#g%hi%[%hi%_%hi%z%hi~O%uWO#g&sa%[&sa%_&sag&sa~Oz,yO#g&sa%[&sa%_&sag&sa~Og,|O~OV)WOa)WO%uWO!W&ua~Oz-OO!W&ua~On$|iz$|i~P%SOV)cO~P'vOV)cOn&wq~P'vOt-SOP#myV#myf#myh#myo#mys#myv#my!P#my!Q#my!T#my!U#my!X#my!]#my!h#my!r#my!s#my!t#my!{#my!}#my#P#my#R#my#T#my#X#my#Z#my#^#my#_#my#a#my#c#my#l#my#o#my#s#my#u#my#z#my#}#my$P#my%X#my%o#my%p#my%t#my%u#my&Z#my&[#my&]#my&^#my&_#my&`#my&a#my&b#my&c#my&d#my&e#my&f#my&g#my&h#my&i#my&j#my%Z#my%_#my~O%Z-WO%_-WO~P`O#q-XOP#nyV#nyf#nyh#nyo#nys#nyv#ny!P#ny!Q#ny!T#ny!U#ny!X#ny!]#ny!h#ny!r#ny!s#ny!t#ny!{#ny!}#ny#P#ny#R#ny#T#ny#X#ny#Z#ny#^#ny#_#ny#a#ny#c#ny#l#ny#o#ny#s#ny#u#ny#z#ny#}#ny$P#ny%X#ny%o#ny%p#ny%t#ny%u#ny&Z#ny&[#ny&]#ny&^#ny&_#ny&`#ny&a#ny&b#ny&c#ny&d#ny&e#ny&f#ny&g#ny&h#ny&i#ny&j#ny%Z#ny%_#ny~Oz-[O{$hO#[-[O~Oo0dOv0rO{&xq~P'vOz-_O{&xq~O%z,SOg&zaz&za~OV)zOa){O%q)|O%uWOg&ya~Oz-cOg&ya~O$S-gO~OV${Oa${Oo0dOv0rO~P'vOo0dOv0rO{-hOz$li!W$li~P'vOo0dOv0rOz$li!W$li~P'vO{-hOz$li!W$li~Oo0dOv0rO{*_O~P'vOo0dOv0rO{*_O!W&Xq~P'vOz-kO!W&Xq~Oo0dOv0rOz-kO!W&Xq~P'vOs-nO!T%bO!U%aOg&Oq!W&Oq![&Oqz&Oq~P!.{Oa*xOo0dOv0rO![&Ty~P'vOz$ji![$ji~P%SOa*xOo0dOv0rO~P'vOV*|Oo0dOv0rO~P'vOV*|Oo0dOv0rO{&lq![&lq!m&lq%z&lq~P'vO{(fO![-sO!m-tO%z-rO~OV%|Oo0dOv0rO#g%hq%[%hq%_%hq%z%hq~P'vO#[-vOz$wa#g$wa%[$wa%_$wag$wa~O%uWO#g&si%[&si%_&sig&si~Oz-xO#g&si%[&si%_&sig&si~OV)WOa)WO%uWO!W&ui~Ot-|OP#m!RV#m!Rf#m!Rh#m!Ro#m!Rs#m!Rv#m!R!P#m!R!Q#m!R!T#m!R!U#m!R!X#m!R!]#m!R!h#m!R!r#m!R!s#m!R!t#m!R!{#m!R!}#m!R#P#m!R#R#m!R#T#m!R#X#m!R#Z#m!R#^#m!R#_#m!R#a#m!R#c#m!R#l#m!R#o#m!R#s#m!R#u#m!R#z#m!R#}#m!R$P#m!R%X#m!R%o#m!R%p#m!R%t#m!R%u#m!R&Z#m!R&[#m!R&]#m!R&^#m!R&_#m!R&`#m!R&a#m!R&b#m!R&c#m!R&d#m!R&e#m!R&f#m!R&g#m!R&h#m!R&i#m!R&j#m!R%Z#m!R%_#m!R~Oo0dOv0rO{&xy~P'vOV)zOa){O%q)|O%uWOg&yi~O$S-gO%Z.UO%_.UO~OV.`Oh.^O!X.]O!]._O!h.XO!s.ZO!t.ZO%p.WO%uWO&Z]O&[]O&]]O&^]O&_]O&`]O&a]O&b]O~Oo0dOv0rOz$lq!W$lq~P'vO{.eOz$lq!W$lq~Oo0dOv0rO{*_O!W&Xy~P'vOz.fO!W&Xy~Oo0dOv.jO~P'vOs-nO!T%bO!U%aOg&Oy!W&Oy![&Oyz&Oy~P!.{O{(fO![.mO~O{(fO![.mO!m.nO~O%uWO#g&sq%[&sq%_&sqg&sq~Oz.pO#g&sq%[&sq%_&sqg&sq~OV)zOa){O%q)|O%uWO~Oh.uO!f.sOz$TX#[$TX%j$TXg$TX~Os$TX{$TX!W$TX![$TX~P$,bO%o.wO%p.wOs$UXz$UX{$UX#[$UX%j$UX!W$UXg$UX![$UX~O!h.yO~Oz.}O#[/PO%j.zOs&|X{&|X!W&|Xg&|X~Oa/SO~P$(WOh.uOs&}Xz&}X{&}X#[&}X%j&}X!W&}Xg&}X![&}X~Os/WO{$hO~Oo0dOv0rOz$ly!W$ly~P'vOo0dOv0rO{*_O!W&X!R~P'vOz/[O!W&X!R~Og&RXs&RX!T&RX!U&RX!W&RX![&RXz&RX~P!.{Os-nO!T%bO!U%aOg&Qa!W&Qa![&Qaz&Qa~O{(fO![/_O~O%uWO#g&sy%[&sy%_&syg&sy~O!f.sOh$[as$[az$[a{$[a#[$[a%j$[a!W$[ag$[a![$[a~O!h/fO~O%o.wO%p.wOs$Uaz$Ua{$Ua#[$Ua%j$Ua!W$Uag$Ua![$Ua~O%j.zOs$Yaz$Ya{$Ya#[$Ya!W$Yag$Ya![$Ya~Os&|a{&|a!W&|ag&|a~P$'zOz/kOs&|a{&|a!W&|ag&|a~O!W/nO~Og/nO~O{/pO~O![/qO~Oo0dOv0rO{*_O!W&X!Z~P'vO{/tO~O%z/uO~P$,bOz/vO#[/PO%j.zOg'PX~Oz/vOg'PX~Og/xO~O!h/yO~O#[/POs%Saz%Sa{%Sa%j%Sa!W%Sag%Sa![%Sa~O#[/PO%j.zOs%Waz%Wa{%Wa!W%Wag%Wa~Os&|i{&|i!W&|ig&|i~P$'zOz/{O#[/PO%j.zO!['Oa~O{$da~P%SOg'Pa~P$'zOz0TOg'Pa~Oa0VO!['Oi~P$(WOz0XO!['Oi~Oz0XO#[/PO%j.zO!['Oi~O#[/PO%j.zOg$biz$bi~O%z0[O~P$,bO#[/PO%j.zOg%Vaz%Va~Og'Pi~P$'zO{0_O~Oa0VO!['Oq~P$(WOz0aO!['Oq~O#[/PO%j.zOz%Ui![%Ui~Oa0VO~P$(WOa0VO!['Oy~P$(WO#[/PO%j.zOg$ciz$ci~O#[/PO%j.zOz%Uq![%Uq~Oz+XO#g%ha%[%ha%_%ha%z%ha~P%SOV%|Oo0dOv0rO~P'vOn0iO~Oo0iO~P'vO{0jO~Ot0kO~P!.{O&]&Z&j&h&i&g&f&d&e&c&b&`&a&_&^&[%u~",
  goto: "!=c'QPPPPPP'RP'Z*s+]+v,b,}-kP.YP'Z.y.y'ZPPP'Z2cPPPPPP2c5VPP5VP7g7p>PPP>S>t>wPP'Z'ZPP?WPP'Z'ZPP'Z'Z'Z'Z'Z?[@U'ZP@XP@_DfHSHWPHZHeHi'ZPPPHlHu'RP'R'RP'RP'RP'RP'RP'R'R'RP'RPP'RPP'RP'RPH{IXIaPIhInPIhPIhIhPPPIhPK|PLVLaLgK|PIhLpPIhPLwL}PMRMgNUNoMRMRNu! SMRMRMRMR! h! n! q! v! y!!T!!Z!!g!!y!#P!#Z!#a!#}!$T!$Z!$e!$k!$q!%T!%_!%e!%k!%q!%{!&R!&X!&_!&e!&o!&u!'P!'V!'`!'f!'u!'}!(X!(`PPPPPPPPPPP!(f!(i!(o!(x!)S!)_PPPPPPPPPPPP!.R!/g!3g!6wPP!7P!7`!7i!8b!8X!8k!8q!8t!8w!8z!9S!9sPPPPPPPPPPPPPPPPP!9v!9z!:QP!:f!:j!:v!;S!;Y!;c!;f!;i!;o!;u!;{!<OP!<W!<a!=]!=`]eOn#g$h)l+w'}`OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$c$e$f$h$o${%Q%X%[%^%a%e%j%l%u%z%|&X&]&f&h&i&p&s&w&z'R'U'g'h'k'm'n'r'w'y'}(R(W(X(_(b(k(m(u(x)U)])_)c)d)h)l)r)v*Q*[*_*`*c*i*j*l*n*q*r*u*x*|*}+Q+X+Z+[+c+p+q+w,P,Q,T,_,`,a,c,d,g,i,k,m,o,q,r,v-_-a-h-k-n.e.f/W/[/t0d0e0f0g0i0j0k0l0m0o0s}!cQ#c#p$R$b$n%c%h%n%o&^&y'b(l(w)b*g*p+o,n/r0h!P!dQ#c#p$R$b$n$s%c%h%n%o&^&y'b(l(w)b*g*p+o,n/r0h!R!eQ#c#p$R$b$n$s$t%c%h%n%o&^&y'b(l(w)b*g*p+o,n/r0h!T!fQ#c#p$R$b$n$s$t$u%c%h%n%o&^&y'b(l(w)b*g*p+o,n/r0h!V!gQ#c#p$R$b$n$s$t$u$v%c%h%n%o&^&y'b(l(w)b*g*p+o,n/r0h!X!hQ#c#p$R$b$n$s$t$u$v$w%c%h%n%o&^&y'b(l(w)b*g*p+o,n/r0h!]!hQ!n#c#p$R$b$n$s$t$u$v$w$x%c%h%n%o&^&y'b(l(w)b*g*p+o,n/r0h'}TOTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$c$e$f$h$o${%Q%X%[%^%a%e%j%l%u%z%|&X&]&f&h&i&p&s&w&z'R'U'g'h'k'm'n'r'w'y'}(R(W(X(_(b(k(m(u(x)U)])_)c)d)h)l)r)v*Q*[*_*`*c*i*j*l*n*q*r*u*x*|*}+Q+X+Z+[+c+p+q+w,P,Q,T,_,`,a,c,d,g,i,k,m,o,q,r,v-_-a-h-k-n.e.f/W/[/t0d0e0f0g0i0j0k0l0m0o0s&cVOYZ[dnprxy}!P!Q!U!i!k!o!p!q!s!t#[#d#g#y#{#}$Q$f$h${%Q%X%[%^%e%j%l%u%z&X&]&h&i&p&s&z'R'U'g'h'k'm'n'r'y(R(X(_(b(k(m(u)U)])_)h)l)r)v*Q*[*_*`*c*i*j*l*n*q*r*u*|*}+Q+X+[+c+w,P,Q,T,_,`,a,c,d,g,i,k,m,o,q,r,v-_-a-h-k-n.e.f/[/t0d0e0f0g0i0j0k0l0o0s%mXOYZ[dnrxy}!P!Q!U!i!k#[#d#g#y#{#}$Q$f$h${%Q%[%^%e%j%l%u%z&X&]&h&i&p&s&z'R'U'g'h'k'm'n'r'y(R(X(_(b(k(m(u)U)])_)h)l)r)v*Q*[*_*`*c*i*l*n*q*r*u*|*}+Q+X+[+c+w,P,Q,T,_,`,a,c,d,g,k,m,o,q,r,v-_-a-h-k.e.f/[0j0k0lQ#vqQ/].jR0p0r't`OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$c$e$f$h$o${%Q%X%[%^%a%e%j%l%u%z%|&X&]&f&h&i&p&s&w&z'R'U'g'k'm'n'r'w'y'}(R(W(X(_(b(k(m(u(x)U)])_)c)d)h)l)r)v*Q*_*`*c*i*j*l*n*q*r*u*x*|*}+Q+X+Z+[+c+p+q+w,P,Q,T,`,a,c,d,g,i,k,m,o,q,r,v-_-a-h-k-n.e.f/W/[/t0d0e0f0g0i0j0k0l0m0o0sW#jhz{$XW#rq&Z.j0rQ$Z|Q$_!OQ$l!VQ$m!WW$z!i'h*[,_S&Y#s#tQ&}$gQ(n&SQ(|&jU(}&l)O)PU)Q&n)R+bW)X&r+e-O-zQ)x'WW)y'Y,W-c.SQ+d)WS,V)z){Y,x+],y-w-x.pQ,{+_Q-Y+{Q-^,OQ.Q-[l.V-g.].^.`.{.}/S/k/p/u/z0V0[0_Q.o-vQ/T._Q/b.uQ/m/PU0Q/v0T0]X0W/{0X0`0aR&X#r!_!wYZ!P!Q!k%Q%^%e'k'm'n'y(R)_*_*`*c*i*l*n,`,a,c,d,g-h-k.e.f/[R%[!vQ!{YQ%v#[Q&b#}Q&e$QR,s+QT.i-n/t![!jQ!n#c#p$R$b$n$s$t$u$v$w$x%c%h%n%o&^&y'b(l(w)b*g*p+o,n/r0hQ&V#kQ'^$mR*U'_R'g$zQ%T!mR/`.s'|_OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$c$e$f$h$o${%Q%X%[%^%a%e%j%l%u%z%|&X&]&f&h&i&p&s&w&z'R'U'g'h'k'm'n'r'w'y'}(R(W(X(_(b(k(m(u(x)U)])_)c)d)h)l)r)v*Q*[*_*`*c*i*j*l*n*q*r*u*x*|*}+Q+X+Z+[+c+p+q+w,P,Q,T,_,`,a,c,d,g,i,k,m,o,q,r,v-_-a-h-k-n.e.f/W/[/t0d0e0f0g0i0j0k0l0m0o0sS#a_#b!P.Z-g.].^._.`.u.{.}/S/k/p/u/v/z/{0T0V0X0[0]0_0`0a'|_OTYZ[adnoprtxy}!P!Q!R!U!X!c!d!e!f!g!h!i!k!o!p!q!s!t!z#O#S#T#[#d#g#x#y#{#}$Q$c$e$f$h$o${%Q%X%[%^%a%e%j%l%u%z%|&X&]&f&h&i&p&s&w&z'R'U'g'h'k'm'n'r'w'y'}(R(W(X(_(b(k(m(u(x)U)])_)c)d)h)l)r)v*Q*[*_*`*c*i*j*l*n*q*r*u*x*|*}+Q+X+Z+[+c+p+q+w,P,Q,T,_,`,a,c,d,g,i,k,m,o,q,r,v-_-a-h-k-n.e.f/W/[/t0d0e0f0g0i0j0k0l0m0o0sT#a_#bT#^^#_R(j%va(g%v(i(j+W,s-t-u.nT+S(f+TR-u,sQ$PsQ+d)XR,U)yX#}s$O$P&dQ&t$_Q'[$lQ'_$mR)k&}Q)Y&rV,}+e-O-zZgOn$h)l+wXkOn)l+wQ$i!TQ&u$`Q&v$aQ'X$kQ']$mQ)i&|Q)p'RQ)s'SQ)t'TQ*R'ZS*T'^'_Q+k)_Q+m)`Q+n)aQ+r)gS+t)j*SQ+x)nQ+y)oS+z)q)rQ,[*UQ-Q+jQ-R+lQ-T+sS-U+u+vQ-Z+|Q-]+}Q-{-SQ-}-VQ.O-XQ.P-YQ.q-|Q.r.QQ/X.cR/s/YWkOn)l+wR#mjQ'Z$lS)j&}'[R+v)kQ,T)yR-a,UQ*S'ZQ+u)jR-V+vZiOjn)l+wQ'a$nR*W'bT-e,]-fu.b-g.].^.`.u.{.}/S/k/p/u/v/z0T0V0[0]0_t.b-g.].^.`.u.{.}/S/k/p/u/v/z0T0V0[0]0_Q/T._X0W/{0X0`0a!P.Y-g.].^._.`.u.{.}/S/k/p/u/v/z/{0T0V0X0[0]0_0`0aQ.x.XR/g.yg.{.[.|/c/j/o/}0P0R0^0b0cu.a-g.].^.`.u.{.}/S/k/p/u/v/z0T0V0[0]0_X.v.V.a/b0QR/d.uV0S/v0T0]R/Y.cQnOS#on+wR+w)lQ&[#uR(s&[S%k#R#wS(Y%k(]T(]%n&^Q%_!yQ%f!}W'z%_%f(P(TQ(P%cR(T%hQ&g$RR(y&gQ(`%oQ*s(ZT*y(`*sQ'i$|R*]'iS'l%P%QY*a'l*b,e-l.gU*b'm'n'oU,e*c*d*eS-l,f,gR.g-mQ#Y]R%r#YQ#_^R%w#_Q(c%tS+O(c+PR+P(dQ+T(fR,t+TQ#b_R%y#bQ#ebQ%{#cW&O#e%{(v+YQ(v&aR+Y0hQ$OsS&c$O&dR&d$PQ&q$]R)V&qQ&T#jR(o&TQ$X{R&k$XQ+^(}S,z+^-yR-y,{Q&o$ZR)S&oQ+f)YR-P+fQ#hfR&Q#hQ)^&uR+i)^Q&x$bS)e&x)fR)f&yQ'Q$iR)m'QQ'V$jS)w'V,RR,R)xQ,X)}R-d,XWjOn)l+wR#ljQ-f,]R.T-fd.|.[/c/j/o/}0P0R0^0b0cR/i.|U.t.V/b0QR/a.tQ/|/oS0Y/|0ZR0Z/}S/w/c/dR0U/wQ/O.[R/l/OR!ZPXmOn)l+wWlOn)l+wR'O$hYfOn$h)l+wR&P#g[sOn#g$h)l+wR&b#}&bQOYZ[dnprxy}!P!Q!U!i!k!o!p!q!s!t#[#d#g#y#{#}$Q$f$h${%Q%X%[%^%e%j%l%u%z&X&]&h&i&p&s&z'R'U'g'h'k'm'n'r'y(R(X(_(b(k(m(u)U)])_)h)l)r)v*Q*[*_*`*c*i*j*l*n*q*r*u*|*}+Q+X+[+c+w,P,Q,T,_,`,a,c,d,g,i,k,m,o,q,r,v-_-a-h-k-n.e.f/[/t0d0e0f0g0i0j0k0l0o0sQ!nTQ#caQ#poU$Rt%a'}S$b!R$eQ$n!XQ$s!cQ$t!dQ$u!eQ$v!fQ$w!gQ$x!hQ%c!zQ%h#OQ%n#SQ%o#TQ&^#xQ&y$cQ'b$oQ(l%|U(w&f(x+ZW)b&w)d+p+qQ*g'wQ*p(WQ+o)cQ,n*xQ/r/WR0h0mQ!yYQ!}ZQ$`!PQ$a!QQ%P!kQ'o%Q^'v%^%e'y(R*i*l*n^*^'k*`,c,d-k.f/[Q*d'mQ*e'nQ+l)_Q,b*_Q,f*cQ-i,`Q-j,aQ-m,gQ.d-hR/Z.e[bOn#g$h)l+w!^!vYZ!P!Q!k%Q%^%e'k'm'n'y(R)_*_*`*c*i*l*n,`,a,c,d,g-h-k.e.f/[Q#R[Q#fdS#wrxQ$UyW$]}$Q&z)hS$j!U$fW$y!i'h*[,_S%t#[+Q`%}#d%z(k(m(u+X,v0lQ&_#yQ&`#{Q&a#}Q'e${Q'u%[W(V%j(X*q*uQ(Z%lQ(d%uQ(q&XS(t&]0jQ(z&hQ({&iU)T&p)U+cQ)[&sQ)q'RY)u'U)v,P,Q-_Q*Y'gS*f'r0kW*w(_*r,k,oW*{(b*},q,rQ+h)]Q+|)rQ,Z*QQ,p*|Q,w+[Q-`,TQ-q,mR.R-ahUOn#d#g$h%z&]'r(k(m)l+w%S!uYZ[drxy}!P!Q!U!i!k#[#y#{#}$Q$f${%Q%[%^%e%j%l%u&X&h&i&p&s&z'R'U'g'h'k'm'n'y(R(X(_(b(u)U)])_)h)r)v*Q*[*_*`*c*i*l*n*q*r*u*|*}+Q+X+[+c,P,Q,T,_,`,a,c,d,g,k,m,o,q,r,v-_-a-h-k.e.f/[0j0k0lQ#qpW%U!o!s0e0oQ%V!pQ%W!qQ%Y!tQ%d0dS'q%X0iQ's0fQ't0gQ,h*jQ-p,iS.h-n/tR0q0sU#uq.j0rR(r&Z[cOn#g$h)l+wZ!xY#[#}$Q+QQ#W[Q#zrR$TxQ%`!yQ%g!}Q%m#RQ'e$yQ(Q%cQ(U%hQ(^%nQ(a%oQ*t(ZQ,^*YQ-o,hQ.l-pR/^.kQ$StQ'|%aR*k'}Q.k-nR0O/tR#QZR#V[R%O!iQ$|!iV*Z'h*[,_!]!lQ!n#c#p$R$b$n$s$t$u$v$w$x%c%h%n%o&^&y'b(l(w)b*g*p+o,n/r0hR%R!kT#]^#_Q%v#[R,s+QQ(h%vS+V(i(jQ,u+WQ-s,sS.m-t-uR/_.nT+R(f+TQ$^}Q&e$QQ)g&zR+s)hQ#khQ$VzQ$Y{R&m$XQ(|&lR+a)PQ(|&lQ+`)OR+a)PR$[|R)Z&rXlOn)l+wQ$d!RR&{$eQ$k!UR&|$fR*P'YQ)}'YV-b,W-c.SQ.c-gQ/Q.]R/R.^U.[-g.].^Q/V.`Q/c.uQ/h.{U/j.}/k/zQ/o/SQ/}/pQ0P/uU0R/v0T0]Q0^0VQ0b0[R0c0_R/U._R/e.u",
  nodeNames: "⚠ print Escape { Comment Script AssignStatement * BinaryExpression BitOp BitOp BitOp BitOp ArithOp ArithOp @ ArithOp ** UnaryExpression ArithOp BitOp AwaitExpression await ) ( ParenthesizedExpression BinaryExpression or and CompareOp in not is UnaryExpression ConditionalExpression if else LambdaExpression lambda ParamList VariableName AssignOp , : NamedExpression AssignOp YieldExpression yield from TupleExpression ComprehensionExpression async for LambdaExpression ] [ ArrayExpression ArrayComprehensionExpression } { DictionaryExpression DictionaryComprehensionExpression SetExpression SetComprehensionExpression CallExpression ArgList AssignOp MemberExpression . PropertyName Number String FormatString FormatReplacement FormatSelfDoc FormatConversion FormatSpec FormatReplacement FormatSelfDoc ContinuedString Ellipsis None Boolean TypeDef AssignOp UpdateStatement UpdateOp ExpressionStatement DeleteStatement del PassStatement pass BreakStatement break ContinueStatement continue ReturnStatement return YieldStatement PrintStatement RaiseStatement raise ImportStatement import as ScopeStatement global nonlocal AssertStatement assert TypeDefinition type TypeParamList TypeParam StatementGroup ; IfStatement Body elif WhileStatement while ForStatement TryStatement try except finally WithStatement with FunctionDefinition def ParamList AssignOp TypeDef ClassDefinition class DecoratedStatement Decorator At MatchStatement match MatchBody MatchClause case CapturePattern LiteralPattern ArithOp ArithOp AsPattern OrPattern LogicOp AttributePattern SequencePattern MappingPattern StarPattern ClassPattern PatternArgList KeywordPattern KeywordPattern Guard",
  maxTerm: 277,
  context: da,
  nodeProps: [
    ["isolate", -5, 4, 71, 72, 73, 77, ""],
    ["group", -15, 6, 85, 87, 88, 90, 92, 94, 96, 98, 99, 100, 102, 105, 108, 110, "Statement Statement", -22, 8, 18, 21, 25, 40, 49, 50, 56, 57, 60, 61, 62, 63, 64, 67, 70, 71, 72, 79, 80, 81, 82, "Expression", -10, 114, 116, 119, 121, 122, 126, 128, 133, 135, 138, "Statement", -9, 143, 144, 147, 148, 150, 151, 152, 153, 154, "Pattern"],
    ["openedBy", 23, "(", 54, "[", 58, "{"],
    ["closedBy", 24, ")", 55, "]", 59, "}"]
  ],
  propSources: [Sa],
  skippedNodes: [0, 4],
  repeatNodeCount: 34,
  tokenData: "!2|~R!`OX%TXY%oY[%T[]%o]p%Tpq%oqr'ars)Yst*xtu%Tuv,dvw-hwx.Uxy/tyz0[z{0r{|2S|}2p}!O3W!O!P4_!P!Q:Z!Q!R;k!R![>_![!]Do!]!^Es!^!_FZ!_!`Gk!`!aHX!a!b%T!b!cIf!c!dJU!d!eK^!e!hJU!h!i!#f!i!tJU!t!u!,|!u!wJU!w!x!.t!x!}JU!}#O!0S#O#P&o#P#Q!0j#Q#R!1Q#R#SJU#S#T%T#T#UJU#U#VK^#V#YJU#Y#Z!#f#Z#fJU#f#g!,|#g#iJU#i#j!.t#j#oJU#o#p!1n#p#q!1s#q#r!2a#r#s!2f#s$g%T$g;'SJU;'S;=`KW<%lOJU`%YT&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T`%lP;=`<%l%To%v]&n`%c_OX%TXY%oY[%T[]%o]p%Tpq%oq#O%T#O#P&o#P#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To&tX&n`OY%TYZ%oZ]%T]^%o^#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc'f[&n`O!_%T!_!`([!`#T%T#T#U(r#U#f%T#f#g(r#g#h(r#h#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc(cTmR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc(yT!mR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk)aV&n`&[ZOr%Trs)vs#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk){V&n`Or%Trs*bs#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk*iT&n`&^ZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To+PZS_&n`OY*xYZ%TZ]*x]^%T^#o*x#o#p+r#p#q*x#q#r+r#r;'S*x;'S;=`,^<%lO*x_+wTS_OY+rZ]+r^;'S+r;'S;=`,W<%lO+r_,ZP;=`<%l+ro,aP;=`<%l*xj,kV%rQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj-XT!xY&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj-oV%lQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk.]V&n`&ZZOw%Twx.rx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk.wV&n`Ow%Twx/^x#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk/eT&n`&]ZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk/{ThZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc0cTgR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk0yXVZ&n`Oz%Tz{1f{!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk1mVaR&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk2ZV%oZ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc2wTzR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To3_W%pZ&n`O!_%T!_!`-Q!`!a3w!a#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Td4OT&{S&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk4fX!fQ&n`O!O%T!O!P5R!P!Q%T!Q![6T![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk5WV&n`O!O%T!O!P5m!P#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk5tT!rZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti6[a!hX&n`O!Q%T!Q![6T![!g%T!g!h7a!h!l%T!l!m9s!m#R%T#R#S6T#S#X%T#X#Y7a#Y#^%T#^#_9s#_#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti7fZ&n`O{%T{|8X|}%T}!O8X!O!Q%T!Q![8s![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti8^V&n`O!Q%T!Q![8s![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti8z]!hX&n`O!Q%T!Q![8s![!l%T!l!m9s!m#R%T#R#S8s#S#^%T#^#_9s#_#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti9zT!hX&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk:bX%qR&n`O!P%T!P!Q:}!Q!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj;UV%sQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti;ro!hX&n`O!O%T!O!P=s!P!Q%T!Q![>_![!d%T!d!e?q!e!g%T!g!h7a!h!l%T!l!m9s!m!q%T!q!rA]!r!z%T!z!{Bq!{#R%T#R#S>_#S#U%T#U#V?q#V#X%T#X#Y7a#Y#^%T#^#_9s#_#c%T#c#dA]#d#l%T#l#mBq#m#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti=xV&n`O!Q%T!Q![6T![#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti>fc!hX&n`O!O%T!O!P=s!P!Q%T!Q![>_![!g%T!g!h7a!h!l%T!l!m9s!m#R%T#R#S>_#S#X%T#X#Y7a#Y#^%T#^#_9s#_#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti?vY&n`O!Q%T!Q!R@f!R!S@f!S#R%T#R#S@f#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Ti@mY!hX&n`O!Q%T!Q!R@f!R!S@f!S#R%T#R#S@f#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiAbX&n`O!Q%T!Q!YA}!Y#R%T#R#SA}#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiBUX!hX&n`O!Q%T!Q!YA}!Y#R%T#R#SA}#S#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiBv]&n`O!Q%T!Q![Co![!c%T!c!iCo!i#R%T#R#SCo#S#T%T#T#ZCo#Z#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TiCv]!hX&n`O!Q%T!Q![Co![!c%T!c!iCo!i#R%T#R#SCo#S#T%T#T#ZCo#Z#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%ToDvV{_&n`O!_%T!_!`E]!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TcEdT%{R&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkEzT#gZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkFbXmR&n`O!^%T!^!_F}!_!`([!`!a([!a#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TjGUV%mQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkGrV%zZ&n`O!_%T!_!`([!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkH`WmR&n`O!_%T!_!`([!`!aHx!a#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TjIPV%nQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkIoV_Q#}P&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%ToJ_]&n`&YS%uZO!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUoKZP;=`<%lJUoKge&n`&YS%uZOr%Trs)Ysw%Twx.Ux!Q%T!Q![JU![!c%T!c!tJU!t!uLx!u!}JU!}#R%T#R#SJU#S#T%T#T#fJU#f#gLx#g#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUoMRa&n`&YS%uZOr%TrsNWsw%Twx! vx!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUkN_V&n`&`ZOr%TrsNts#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%TkNyV&n`Or%Trs! `s#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk! gT&n`&bZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk! }V&n`&_ZOw%Twx!!dx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!!iV&n`Ow%Twx!#Ox#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!#VT&n`&aZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To!#oe&n`&YS%uZOr%Trs!%Qsw%Twx!&px!Q%T!Q![JU![!c%T!c!tJU!t!u!(`!u!}JU!}#R%T#R#SJU#S#T%T#T#fJU#f#g!(`#g#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUk!%XV&n`&dZOr%Trs!%ns#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!%sV&n`Or%Trs!&Ys#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!&aT&n`&fZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!&wV&n`&cZOw%Twx!'^x#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!'cV&n`Ow%Twx!'xx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!(PT&n`&eZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To!(ia&n`&YS%uZOr%Trs!)nsw%Twx!+^x!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUk!)uV&n`&hZOr%Trs!*[s#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!*aV&n`Or%Trs!*vs#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!*}T&n`&jZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!+eV&n`&gZOw%Twx!+zx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!,PV&n`Ow%Twx!,fx#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tk!,mT&n`&iZO#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%To!-Vi&n`&YS%uZOr%TrsNWsw%Twx! vx!Q%T!Q![JU![!c%T!c!dJU!d!eLx!e!hJU!h!i!(`!i!}JU!}#R%T#R#SJU#S#T%T#T#UJU#U#VLx#V#YJU#Y#Z!(`#Z#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUo!.}a&n`&YS%uZOr%Trs)Ysw%Twx.Ux!Q%T!Q![JU![!c%T!c!}JU!}#R%T#R#SJU#S#T%T#T#oJU#p#q%T#r$g%T$g;'SJU;'S;=`KW<%lOJUk!0ZT!XZ&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tc!0qT!WR&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%Tj!1XV%kQ&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T~!1sO!]~k!1zV%jR&n`O!_%T!_!`-Q!`#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T~!2fO![~i!2mT%tX&n`O#o%T#p#q%T#r;'S%T;'S;=`%i<%lO%T",
  tokenizers: [sa, Qa, ra, Ta, 0, 1, 2, 3, 4],
  topRules: { Script: [0, 5] },
  specialized: [{ term: 221, get: (O) => pa[O] || -1 }],
  tokenPrec: 7646
}), x = /* @__PURE__ */ new nO(), J = /* @__PURE__ */ new Set([
  "Script",
  "Body",
  "FunctionDefinition",
  "ClassDefinition",
  "LambdaExpression",
  "ForStatement",
  "MatchClause"
]);
function m(O) {
  return (e, a, i) => {
    if (i)
      return !1;
    let r = e.node.getChild("VariableName");
    return r && a(r, O), !0;
  };
}
const Pa = {
  FunctionDefinition: /* @__PURE__ */ m("function"),
  ClassDefinition: /* @__PURE__ */ m("class"),
  ForStatement(O, e, a) {
    if (a) {
      for (let i = O.node.firstChild; i; i = i.nextSibling)
        if (i.name == "VariableName")
          e(i, "variable");
        else if (i.name == "in")
          break;
    }
  },
  ImportStatement(O, e) {
    var a, i;
    let { node: r } = O, S = ((a = r.firstChild) === null || a === void 0 ? void 0 : a.name) == "from";
    for (let Q = r.getChild("import"); Q; Q = Q.nextSibling)
      Q.name == "VariableName" && ((i = Q.nextSibling) === null || i === void 0 ? void 0 : i.name) != "as" && e(Q, S ? "variable" : "namespace");
  },
  AssignStatement(O, e) {
    for (let a = O.node.firstChild; a; a = a.nextSibling)
      if (a.name == "VariableName")
        e(a, "variable");
      else if (a.name == ":" || a.name == "AssignOp")
        break;
  },
  ParamList(O, e) {
    for (let a = null, i = O.node.firstChild; i; i = i.nextSibling)
      i.name == "VariableName" && (!a || !/\*|AssignOp/.test(a.name)) && e(i, "variable"), a = i;
  },
  CapturePattern: /* @__PURE__ */ m("variable"),
  AsPattern: /* @__PURE__ */ m("variable"),
  __proto__: null
};
function C(O, e) {
  let a = x.get(e);
  if (a)
    return a;
  let i = [], r = !0;
  function S(Q, t) {
    let P = O.sliceString(Q.from, Q.to);
    i.push({ label: P, type: t });
  }
  return e.cursor(eO.IncludeAnonymous).iterate((Q) => {
    if (Q.name) {
      let t = Pa[Q.name];
      if (t && t(Q, S, r) || !r && J.has(Q.name))
        return !1;
      r = !1;
    } else if (Q.to - Q.from > 8192) {
      for (let t of C(O, Q.node))
        i.push(t);
      return !1;
    }
  }), x.set(e, i), i;
}
const U = /^[\w\xa1-\uffff][\w\d\xa1-\uffff]*$/, I = ["String", "FormatString", "Comment", "PropertyName"];
function ma(O) {
  let e = L(O.state).resolveInner(O.pos, -1);
  if (I.indexOf(e.name) > -1)
    return null;
  let a = e.name == "VariableName" || e.to - e.from < 20 && U.test(O.state.sliceDoc(e.from, e.to));
  if (!a && !O.explicit)
    return null;
  let i = [];
  for (let r = e; r; r = r.parent)
    J.has(r.name) && (i = i.concat(C(O.state.doc, r)));
  return {
    options: i,
    from: a ? e.from : O.pos,
    validFor: U
  };
}
const $a = /* @__PURE__ */ [
  "__annotations__",
  "__builtins__",
  "__debug__",
  "__doc__",
  "__import__",
  "__name__",
  "__loader__",
  "__package__",
  "__spec__",
  "False",
  "None",
  "True"
].map((O) => ({ label: O, type: "constant" })).concat(/* @__PURE__ */ [
  "ArithmeticError",
  "AssertionError",
  "AttributeError",
  "BaseException",
  "BlockingIOError",
  "BrokenPipeError",
  "BufferError",
  "BytesWarning",
  "ChildProcessError",
  "ConnectionAbortedError",
  "ConnectionError",
  "ConnectionRefusedError",
  "ConnectionResetError",
  "DeprecationWarning",
  "EOFError",
  "Ellipsis",
  "EncodingWarning",
  "EnvironmentError",
  "Exception",
  "FileExistsError",
  "FileNotFoundError",
  "FloatingPointError",
  "FutureWarning",
  "GeneratorExit",
  "IOError",
  "ImportError",
  "ImportWarning",
  "IndentationError",
  "IndexError",
  "InterruptedError",
  "IsADirectoryError",
  "KeyError",
  "KeyboardInterrupt",
  "LookupError",
  "MemoryError",
  "ModuleNotFoundError",
  "NameError",
  "NotADirectoryError",
  "NotImplemented",
  "NotImplementedError",
  "OSError",
  "OverflowError",
  "PendingDeprecationWarning",
  "PermissionError",
  "ProcessLookupError",
  "RecursionError",
  "ReferenceError",
  "ResourceWarning",
  "RuntimeError",
  "RuntimeWarning",
  "StopAsyncIteration",
  "StopIteration",
  "SyntaxError",
  "SyntaxWarning",
  "SystemError",
  "SystemExit",
  "TabError",
  "TimeoutError",
  "TypeError",
  "UnboundLocalError",
  "UnicodeDecodeError",
  "UnicodeEncodeError",
  "UnicodeError",
  "UnicodeTranslateError",
  "UnicodeWarning",
  "UserWarning",
  "ValueError",
  "Warning",
  "ZeroDivisionError"
].map((O) => ({ label: O, type: "type" }))).concat(/* @__PURE__ */ [
  "bool",
  "bytearray",
  "bytes",
  "classmethod",
  "complex",
  "float",
  "frozenset",
  "int",
  "list",
  "map",
  "memoryview",
  "object",
  "range",
  "set",
  "staticmethod",
  "str",
  "super",
  "tuple",
  "type"
].map((O) => ({ label: O, type: "class" }))).concat(/* @__PURE__ */ [
  "abs",
  "aiter",
  "all",
  "anext",
  "any",
  "ascii",
  "bin",
  "breakpoint",
  "callable",
  "chr",
  "compile",
  "delattr",
  "dict",
  "dir",
  "divmod",
  "enumerate",
  "eval",
  "exec",
  "exit",
  "filter",
  "format",
  "getattr",
  "globals",
  "hasattr",
  "hash",
  "help",
  "hex",
  "id",
  "input",
  "isinstance",
  "issubclass",
  "iter",
  "len",
  "license",
  "locals",
  "max",
  "min",
  "next",
  "oct",
  "open",
  "ord",
  "pow",
  "print",
  "property",
  "quit",
  "repr",
  "reversed",
  "round",
  "setattr",
  "slice",
  "sorted",
  "sum",
  "vars",
  "zip"
].map((O) => ({ label: O, type: "function" }))), ga = [
  /* @__PURE__ */ o("def ${name}(${params}):\n	${}", {
    label: "def",
    detail: "function",
    type: "keyword"
  }),
  /* @__PURE__ */ o("for ${name} in ${collection}:\n	${}", {
    label: "for",
    detail: "loop",
    type: "keyword"
  }),
  /* @__PURE__ */ o("while ${}:\n	${}", {
    label: "while",
    detail: "loop",
    type: "keyword"
  }),
  /* @__PURE__ */ o("try:\n	${}\nexcept ${error}:\n	${}", {
    label: "try",
    detail: "/ except block",
    type: "keyword"
  }),
  /* @__PURE__ */ o(`if \${}:
	
`, {
    label: "if",
    detail: "block",
    type: "keyword"
  }),
  /* @__PURE__ */ o("if ${}:\n	${}\nelse:\n	${}", {
    label: "if",
    detail: "/ else block",
    type: "keyword"
  }),
  /* @__PURE__ */ o("class ${name}:\n	def __init__(self, ${params}):\n			${}", {
    label: "class",
    detail: "definition",
    type: "keyword"
  }),
  /* @__PURE__ */ o("import ${module}", {
    label: "import",
    detail: "statement",
    type: "keyword"
  }),
  /* @__PURE__ */ o("from ${module} import ${names}", {
    label: "from",
    detail: "import",
    type: "keyword"
  })
], qa = /* @__PURE__ */ H(I, /* @__PURE__ */ iO(/* @__PURE__ */ $a.concat(ga)));
function V(O, e) {
  let a = O.baseIndentFor(e), i = O.lineAt(O.pos, -1), r = i.from + i.text.length;
  return /^\s*($|#)/.test(i.text) && O.node.to < r + 100 && !/\S/.test(O.state.sliceDoc(r, O.node.to)) && O.lineIndent(O.pos, -1) <= a || /^\s*(else:|elif |except |finally:)/.test(O.textAfter) && O.lineIndent(O.pos, -1) > a ? null : a + O.unit;
}
const R = /* @__PURE__ */ B.define({
  name: "python",
  parser: /* @__PURE__ */ ha.configure({
    props: [
      /* @__PURE__ */ K.add({
        Body: (O) => {
          var e;
          return (e = V(O, O.node)) !== null && e !== void 0 ? e : O.continue();
        },
        IfStatement: (O) => /^\s*(else:|elif )/.test(O.textAfter) ? O.baseIndent : O.continue(),
        "ForStatement WhileStatement": (O) => /^\s*else:/.test(O.textAfter) ? O.baseIndent : O.continue(),
        TryStatement: (O) => /^\s*(except |finally:|else:)/.test(O.textAfter) ? O.baseIndent : O.continue(),
        "TupleExpression ComprehensionExpression ParamList ArgList ParenthesizedExpression": /* @__PURE__ */ X({ closing: ")" }),
        "DictionaryExpression DictionaryComprehensionExpression SetExpression SetComprehensionExpression": /* @__PURE__ */ X({ closing: "}" }),
        "ArrayExpression ArrayComprehensionExpression": /* @__PURE__ */ X({ closing: "]" }),
        "String FormatString": () => null,
        Script: (O) => {
          if (O.pos + /\s*/.exec(O.textAfter)[0].length >= O.node.to) {
            let e = null;
            for (let a = O.node, i = a.to; a = a.lastChild, !(!a || a.to != i); )
              a.type.name == "Body" && (e = a);
            if (e) {
              let a = V(O, e);
              if (a != null)
                return a;
            }
          }
          return O.continue();
        }
      }),
      /* @__PURE__ */ M.add({
        "ArrayExpression DictionaryExpression SetExpression TupleExpression": OO,
        Body: (O, e) => ({ from: O.from + 1, to: O.to - (O.to == e.doc.length ? 0 : 1) })
      })
    ]
  }),
  languageData: {
    closeBrackets: {
      brackets: ["(", "[", "{", "'", '"', "'''", '"""'],
      stringPrefixes: [
        "f",
        "fr",
        "rf",
        "r",
        "u",
        "b",
        "br",
        "rb",
        "F",
        "FR",
        "RF",
        "R",
        "U",
        "B",
        "BR",
        "RB"
      ]
    },
    commentTokens: { line: "#" },
    indentOnInput: /^\s*([\}\]\)]|else:|elif |except |finally:)$/
  }
});
function fa() {
  return new aO(R, [
    R.data.of({ autocomplete: ma }),
    R.data.of({ autocomplete: qa })
  ]);
}
export {
  qa as globalCompletion,
  ma as localCompletionSource,
  fa as python,
  R as pythonLanguage
};
